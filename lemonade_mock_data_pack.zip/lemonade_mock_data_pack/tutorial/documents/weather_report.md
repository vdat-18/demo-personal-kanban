# Weather report – Riverside Summer Sounds stall day

**Prepared for:** Summer Sound Lemonade Stand  
**Event date:** 2026-06-14  
**Location:** Riverside Park East Lawn  

## Summary

A warm afternoon and evening are expected, which is favorable for cold drinks.

- 12:00–15:00: 30–32 C, sunny
- 15:00–18:00: 31–33 C, partly cloudy
- 18:00–21:00: 27–29 C, warm evening
- Rain probability: 15%
- Wind: 8–12 km/h
- UV index: high from 12:00–16:00

## Operational implications

1. Demand for cold beverages is likely to increase between 14:00 and 18:30.
2. Ice melt risk is material; replenishment should be planned.
3. Shade, hydration, and breaks are important for staff.
4. A light rain plan is still advisable, but severe weather risk is low.

## Recommendation

Prepare for a **high-volume cold beverage window** from 14:00 to 19:00 and keep a backup canopy plus extra ice.
