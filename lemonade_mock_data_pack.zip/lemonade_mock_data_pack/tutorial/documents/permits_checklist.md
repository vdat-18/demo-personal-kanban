# Permits and compliance checklist

## Required before event day
- Temporary food/beverage vending permit confirmed
- Event organizer vendor approval confirmed
- Proof of liability insurance uploaded
- At least one on-shift worker with food handling certification
- Ingredient allergen summary prepared
- Cashless payment device tested
- Waste disposal and cleanup plan noted

## Nice to have
- QR menu ready
- Backup extension cable
- Backup canopy in case of light rain
- Printed prep checklist for opening and closing
