Feature: Context-first Kanban workflow for the lemonade tutorial

  Scenario: New project shows only the directory tree
    Given a new project has been created
    When the user opens the workspace
    Then the directory tree is unlocked
    And project planning is locked
    And the Kanban board is locked

  Scenario: Planner asks for missing permit context
    Given the user uploaded weather, event, supplier, staffing, and recipe documents
    And the permits checklist has not been uploaded
    When the user asks the planner to summarize the project
    Then the planner requests permit or compliance context
    And the Kanban board remains locked

  Scenario: Board unlocks after planner approval
    Given all required tutorial documents are uploaded
    And the planner generated a summary
    When the user approves the planner summary
    Then the Kanban board unlocks
    And generated tasks appear in todo

  Scenario: Task follows the happy path lifecycle
    Given the task "Choose the launch recipe and pricing" is in todo
    When the user moves the task to planning
    And then to doing
    And attaches a deliverable
    And moves the task to review
    And approves the review
    Then the task is in done

  Scenario: Cancellation counts toward closure
    Given the task "Prepare signage, menu board, and QR menu" is in planning
    When the user moves the task to cancelled
    Then the task is considered closed work

  Scenario: Project cannot close with active tasks remaining
    Given one task is still in review
    When the user attempts to close the project
    Then the close action is rejected

  Scenario: Project closes when all tasks are done or cancelled
    Given all project tasks are done or cancelled
    When the user closes the project
    Then the project status becomes closed
